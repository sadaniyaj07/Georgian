// screens/About.js
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default function About() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>About the App</Text>
      <Text style={styles.content}>
        The Expiry Date Tracker helps you keep track of expiration dates for various products.
        It’s designed for households, businesses, and healthcare professionals.
      </Text>
      <Text style={styles.content}>Our mission is to reduce waste and promote timely usage.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  content: { fontSize: 16, marginBottom: 10 },
});
