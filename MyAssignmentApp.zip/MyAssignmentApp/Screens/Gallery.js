// screens/Gallery.js
import React from 'react';
import { View, Image, StyleSheet } from 'react-native';

export default function Gallery() {
  return (
    <View style={styles.container}>
      {[...Array(6)].map((_, index) => (
        <Image
          key={index}
          source={{ uri: 'https://placekitten.com/200/200' }}
          style={styles.image}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', padding: 10 },
  image: { width: 100, height: 100, margin: 10 },
});
