// screens/Profile.js
import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function Profile() {
  return (
    <View style={styles.container}>
      <Image source={{ uri: 'https://placekitten.com/200/200' }} style={styles.image} />
      <Text style={styles.name}>John Doe</Text>
      <Text style={styles.details}>Age: 30</Text>
      <Text style={styles.details}>Location: New York</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  image: { width: 100, height: 100, borderRadius: 50, marginBottom: 20 },
  name: { fontSize: 20, fontWeight: 'bold' },
  details: { fontSize: 16 },
});
